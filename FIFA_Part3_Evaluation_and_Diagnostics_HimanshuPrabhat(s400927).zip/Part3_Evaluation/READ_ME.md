# Part 3 — Model Evaluation and Diagnostics

This package evaluates both supplied Member 2 models. It preserves the original OLS predictions and chronological split. Supplementary Ridge/Lasso experiments are clearly separated from the supplied models.

## Start here

- `EVALUATION_GUIDE.md`: checked findings, interpretation points and an outline for your own report section.
- `results/model_metrics.csv`: train/test MAE, RMSE, R² and mean residual, including baselines and comparison models.
- `results/task_21/diagnostics.png` and `results/task_22/diagnostics.png`: four-panel diagnostic figures.
- `results/model_comparison.png`: final-test RMSE comparison within each task.
- `results/task_21/` and `results/task_22/`: row-level errors, largest errors, stage summaries and training influence.
- `results/cv_candidate_summary.csv`, `cv_fold_metrics.csv`, `cv_date_windows.csv`: every tuning experiment and chronological validation boundary.
- `results/bootstrap_intervals.csv`: approximate match-resampled uncertainty intervals.
- `results/evaluation_summary.json`: verification results, software versions and hashes of the input files.

## Reproduce

Extract the ZIP, open a terminal in this folder and run:

```bash
python evaluate_part3.py
```

Required packages: numpy, pandas, scipy, scikit-learn, matplotlib, openpyxl. Exact versions used are in `requirements_used.txt`. The script reads only local inputs and regenerates results. No network connection or original joblib file is required. It refits the documented linear regressions and confirms agreement with the saved predictions to within 1e-8.

The `inputs` folder contains the supplied master, both original prediction CSVs and settings, and the supplied 208-row dataset. The original ZIP files are not modified. Spreadsheet values are read in Python; all calculations and plots are made in Python.

## Evaluation design

The two models use the same 82 training matches and 22 testing matches, with a cutoff of 2 July 2026. Task 2.2 keeps both team records from each match together. The script checks dates, row counts, unique keys, target alignment, split separation and reproducibility. It independently reconstructs Task 2.2's prior World Cup match count, goals conceded, host indicator and knockout indicator.

Four expanding date-based validation folds use only the original training partition. Date blocks, rather than individual rows, are split, keeping matches and same-date fixtures together. The windows contain different numbers of observations and cover different tournament phases. Pooled validation RMSE gives each validation observation equal weight. These are model-selection scores, not nested-CV unbiased estimates of a selected procedure.

The fixed candidate grid contains OLS, training-mean and training-median baselines, Ridge alpha in {0.01, 0.1, 1, 10, 100, 1000}, and Lasso alpha in {0.001, 0.01, 0.05, 0.1, 0.5, 1}. StandardScaler is fitted inside each Ridge/Lasso training fold through a pipeline. No feature engineering, scaling or penalty selection uses the final test outcomes. Selected penalties are refitted on the original full training partition before testing. All eight predictors remain available to each model; Lasso may set some coefficients to zero.

The original test scores were already visible in the supplied work. These supplementary comparisons are exploratory evaluation, not a fresh preregistered independent validation. Do not select whichever model looks best on the test set and then call that an unbiased estimate of the selection process.

## Uncertainty and diagnostics

The script uses 3,000 bootstrap resamples of the 22 test matches with seed 20261014. Both team records stay together in Task 2.2. Percentile intervals are conditional on the fitted model and observed test sample. They do not incorporate training variability, uncertainty in sources, or all dependence from teams playing repeatedly. Treat them as approximate descriptive uncertainty, not definitive population inference.

Training Cook's distance above 4/n is only a screening flag. Leverage and Cook's distance are calculated using the actual design rank, including an intercept. Their usual probabilistic interpretation assumes independent errors, which repeated teams and paired observations can violate. No observations are deleted. A flag does not establish a data error.

Q–Q plots describe held-out prediction errors. They do not establish that all regression assumptions hold. Normal residuals are not required merely to calculate MAE or RMSE. Target discreteness, repeated teams and small test samples limit strong distributional claims.

## Scope and sources

This package is Part 3 coding/analysis support and a report outline. The assessment requires your report in your own words. Understand the code, record your actual contribution in Teams, and declare AI assistance.

Predictor source accuracy, availability before kickoff, the June FIFA-ranking publication timing and the flagged Elo values are inherited data-review issues. Successful model reproduction does not certify these inputs. It also does not verify that every earlier match was included in the source's history. The supplied models use a rolling pre-match information setting: later test matches may use results of earlier test matches as known predictors. This is appropriate only for match-by-match prediction, not forecasting all knockout results at the split date.

Technical references:

- https://scikit-learn.org/stable/common_pitfalls.html — training-only preprocessing and data leakage.
- https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.TimeSeriesSplit.html — expanding chronological validation; applied here to distinct dates.
- https://scikit-learn.org/stable/modules/generated/sklearn.metrics.r2_score.html — R² interpretation.

Low R² is not by itself a failure to meet the rubric. Scientific rigour requires reporting the actual limitations and unsuccessful optimisation attempts honestly. No HD mark is guaranteed by this package.
