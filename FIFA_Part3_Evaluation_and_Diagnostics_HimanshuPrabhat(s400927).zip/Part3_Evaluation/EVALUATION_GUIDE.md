# Part 3 findings and report outline

Use these checked facts to write your own evaluation section. This is an evidence guide, not a submission-ready report draft.

## 1. Verified evaluation setup

- Task 2.1: eight predictors; 82 training matches and 22 test matches; target = Team A goals minus Team B goals.
- Task 2.2: eight predictors; 164 training team rows and 44 test team rows; target = team goals scored.
- Both use test matches 83–104, starting 2 July 2026. Both sides of each match stay in the same partition.
- All supplied OLS predictions reproduce within 5 × 10^-15 after refitting. There is no material numerical discrepancy.
- The baseline uses the training target mean, not the test mean. A training-median baseline is also included.
- Every test match is a knockout-stage match, including the bronze final. The evaluation is therefore a later-stage holdout, not a representative sample of all tournament matches.

## 2. Main metrics: retain these for the supplied group models

| Task | Partition | Rows | MAE | RMSE | R² |
|---|---|---:|---:|---:|---:|
| 2.1 | Train | 82 | 1.207 | 1.545 | 0.449 |
| 2.1 | Test | 22 | 1.249 | 1.540 | 0.115 |
| 2.2 | Train | 164 | 0.964 | 1.268 | 0.188 |
| 2.2 | Test | 44 | 0.982 | 1.266 | 0.084 |

Interpretation points:

- Task 2.1's test prediction differs from the actual goal difference by approximately 1.25 goals on average.
- Task 2.2's test prediction differs from the actual team goal count by approximately 0.98 goals on average.
- RMSE exceeds MAE in both tasks, showing that larger errors matter.
- R² values of 0.115 and 0.084 indicate limited predictive fit on these test outcomes. They are not 11.5% or 8.4% classification accuracy.
- Training and test RMSE are very similar. The drop in R² alone does not prove overfitting: R² also depends on outcome variation, and the test sample has a different stage composition and variance.
- Do not rank the two tasks solely by their different MAE/RMSE values: the targets and their variation differ.

## 3. Baseline comparisons

| Task | Model | Test MAE | Test RMSE |
|---|---|---:|---:|
| 2.1 | Training-mean baseline | 1.466 | 1.768 |
| 2.1 | Training-median baseline | 1.409 | 1.638 |
| 2.1 | Supplied OLS | 1.249 | 1.540 |
| 2.2 | Training-mean baseline | 1.065 | 1.324 |
| 2.2 | Training-median baseline | 1.023 | 1.422 |
| 2.2 | Supplied OLS | 0.982 | 1.266 |

- Relative to the training-mean baseline, test RMSE is about 12.9% lower for Task 2.1 and 4.3% lower for Task 2.2.
- Those are observed sample improvements. The approximate paired bootstrap intervals for baseline RMSE minus model RMSE include zero in both tasks: [-0.025, 0.445] and [-0.042, 0.148] goals. Strong claims of reliably superior future performance are not supported.

## 4. Residual and error analysis

Task 2.1:

- Mean test residual = -0.748 goals. With residual defined as actual minus predicted, the model overpredicts Team A's goal difference by about 0.75 goals on average in this test set.
- Largest error: USA–Belgium, match 94. Actual difference -3, predicted -0.022, absolute error 2.978.
- Canada–Morocco, match 90: actual -3, predicted -0.269, absolute error 2.731.
- France–England, match 103: actual -2, predicted +0.720, absolute error 2.720.
- The actual-versus-predicted panel shows several substantial Team A losses predicted nearer to a draw. The Q–Q plot is roughly linear around a non-zero residual mean; this does not remove the bias problem.
- Six negative goal-difference predictions are valid because Team A can lose. Do not clip them to zero.

Task 2.2:

- Mean test residual = +0.009 goals. Average bias is close to zero, but positive and negative errors cancel, so this does not imply accurate individual predictions.
- England against France in match 103: actual 6, predicted 1.678, underprediction 4.322 goals.
- Belgium against USA in match 94: actual 4, predicted 1.506, underprediction 2.494 goals.
- France against England in match 103: actual 4, predicted 1.751, underprediction 2.249 goals.
- Predictions are concentrated around moderate scoring values and miss high-scoring outcomes. The right tail of the Q–Q plot highlights this issue.
- None of the 44 supplied test predictions is negative. Ordinary linear regression can produce negative future goal predictions, but do not falsely claim it did so in this test set.
- Do not delete match 103 simply because it increases RMSE. It is a legitimate recorded match.

Training influence:

- Task 2.1 has six observations above the Cook's distance screening threshold 4/82; Task 2.2 has seven above 4/164.
- Both final training design matrices have full rank, nine columns including the intercept.
- Use the saved influence CSVs to discuss sensitivity and review unusual records. No records were removed, and a sensitivity refit was not performed.

## 5. Supplementary systematic model comparisons

These experiments were added for Part 3. They are not claimed to be Member 2's original training workflow. Coordinate their inclusion with Member 2 and Member 4.

| Task | Model | Selected alpha | Test MAE | Test RMSE | Test R² |
|---|---|---:|---:|---:|---:|
| 2.1 | Supplied OLS | — | 1.249 | 1.540 | 0.115 |
| 2.1 | Ridge | 10 | 1.245 | 1.542 | 0.113 |
| 2.1 | Lasso | 0.1 | 1.234 | 1.502 | 0.158 |
| 2.2 | Supplied OLS | — | 0.982 | 1.266 | 0.084 |
| 2.2 | Ridge | 100 | 1.003 | 1.275 | 0.070 |
| 2.2 | Lasso | 0.1 | 1.035 | 1.288 | 0.052 |

Selection and recommendation points:

- Task 2.1: training-only validation selected Ridge alpha 10, with pooled validation RMSE 1.693. It did not improve final-test RMSE over OLS. Lasso's lower test RMSE is a descriptive result, not a valid reason to retrospectively select it using the test set.
- Task 2.2: training-only validation selected Lasso alpha 0.1, with pooled validation RMSE 1.306. It performed worse than OLS on the final holdout. The regularisation improvement did not transfer to that sample.
- Retain the supplied OLS results as the evaluation of the group's current models. Report that the CV-selected alternatives did not establish an improvement on the final test set. For future model development, validate the CV-selected candidates on additional independent data before making a replacement claim.
- Do not claim every optimisation attempt improved performance. Honest negative results are evidence of critical evaluation.
- Task 2.2's `is_knockout` feature is constant in every CV training window. The first window also has constant prior World Cup match count and goals conceded. These temporal coverage limitations reduce the evidence for estimating their effects, especially at the group-to-knockout transition. See `cv_date_windows.csv`.
- The earliest Task 2.1 fold has only 16 training observations for eight predictors plus intercept. The resulting validation estimates are unstable; keep this visible in the limitations.

## 6. Uncertainty

Approximate 95% percentile intervals from resampling whole test matches:

| Task | MAE interval | RMSE interval | R² interval |
|---|---|---|---|
| 2.1 | 0.873–1.640 | 1.139–1.887 | -0.422–0.352 |
| 2.2 | 0.712–1.286 | 0.902–1.662 | -0.130–0.206 |

- Only 22 test matches are available for each task. Task 2.2's 44 rows are not 44 independent matches.
- Resampling pairs preserves within-match pairing, but repeated teams across matches remain dependent. The intervals are approximate and conditional on the supplied fitted models.
- Negative lower R² limits indicate uncertainty about whether future predictive performance will exceed a constant reference. R² is not the square of a correlation here and may be negative.
- Input accuracy and pre-match availability remain separate questions from successful code reproduction. The source workbook's FIFA-ranking date and Elo review notes still require the group's attention.

## 7. Outline for your own report section

The four-page limit covers the entire group report and both regression tasks. Agree your space with the group; approximately 250–350 words plus a compact metrics table or combined figure may be workable, but it is not a prescribed word allocation.

1. Evaluation design: chronological cutoff, train/test sizes, paired team handling and why test predictions are used.
2. Main results: both models' MAE/RMSE/R² and baseline comparison, with clear units.
3. Diagnostics: Task 2.1's directional bias; Task 2.2's high-score underprediction; one concrete match example.
4. Comparison and limitations: training-only CV, unsuccessful transfer of regularisation improvements, knockout-only test set and small dependent sample.
5. Recommendation: cautious use, transparent uncertainty and further independent validation. Avoid causal or guaranteed-prediction claims.

Use `model_comparison.png` for model comparison and the diagnostic panels for error patterns. The full 2×2 panels may be too large for the four-page report; select only the most informative panel(s) or include full versions as supplementary material. Do not replace substantive interpretation with many small unreadable plots.

## 8. Questions you should be able to answer

- Why are train and test metrics reported separately?
- Why does RMSE penalise large misses more strongly than MAE?
- Why can R² fall while RMSE stays similar?
- Why must both team rows stay together in Task 2.2?
- Why is a near-zero average residual insufficient evidence of accuracy?
- Why was training-only CV used to select penalties?
- Why should the best test-set model not automatically be selected?
- Why are the confidence intervals approximate?
- Which data-provenance issues remain unresolved?
