"""Part 3: reproducible evaluation of supplied FIFA regression predictions.
Run: python evaluate_part3.py
Requires numpy, pandas, scipy, scikit-learn, matplotlib and openpyxl.
Preserves Member 2's OLS predictions and chronological split. Comparison models
are supplementary experiments; tuning never uses the final test partition.
"""
from pathlib import Path
import json
import hashlib
import warnings
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy import stats
from sklearn.linear_model import LinearRegression, Ridge, Lasso
from sklearn.dummy import DummyRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.model_selection import TimeSeriesSplit
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.exceptions import ConvergenceWarning
import sklearn

ROOT = Path(__file__).resolve().parent
INPUT = ROOT/'inputs'
OUT = ROOT/'results'
OUT.mkdir(exist_ok=True)
warnings.filterwarnings('error', category=ConvergenceWarning)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,
    'axes.spines.top':False,'axes.spines.right':False,'axes.titleweight':'bold',
    'figure.facecolor':'white','savefig.facecolor':'white'})

def scores(y, pred):
    y,pred=np.asarray(y,float),np.asarray(pred,float)
    return {'n':len(y),'MAE':mean_absolute_error(y,pred),
        'RMSE':float(np.sqrt(mean_squared_error(y,pred))),
        'R2':r2_score(y,pred) if len(y)>1 and np.var(y)>0 else np.nan,
        'mean_residual':float(np.mean(y-pred))}

def estimator(name, alpha=None):
    if name=='OLS':return LinearRegression()
    if name=='Mean baseline':return DummyRegressor(strategy='mean')
    if name=='Median baseline':return DummyRegressor(strategy='median')
    reg=Ridge(alpha=alpha) if name=='Ridge' else Lasso(alpha=alpha,max_iter=100000,tol=1e-8)
    return make_pipeline(StandardScaler(),reg)

def date_folds(data,n=4):
    dates=np.sort(data.match_date.unique())
    folds=[]
    for tr,va in TimeSeriesSplit(n_splits=n).split(dates):
        ti=np.flatnonzero(data.match_date.isin(dates[tr]).to_numpy())
        vi=np.flatnonzero(data.match_date.isin(dates[va]).to_numpy())
        assert data.iloc[ti].match_date.max()<data.iloc[vi].match_date.min()
        assert set(data.iloc[ti].match_id).isdisjoint(data.iloc[vi].match_id)
        folds.append((ti,vi))
    return folds

def bootstrap_metrics(test, repeats=3000):
    # Resample entire matches; both team rows stay together in Task 2.2.
    # This does not remove dependence from repeated teams across matches.
    rng=np.random.default_rng(20261014)
    groups=[g.index.to_numpy() for _,g in test.reset_index(drop=True).groupby('match_id')]
    t=test.reset_index(drop=True)
    vals=[]
    for _ in range(repeats):
        ix=np.concatenate([groups[i] for i in rng.integers(0,len(groups),len(groups))])
        a=t.iloc[ix]
        m=scores(a.actual,a.predicted)
        m['RMSE_gain_vs_mean']=scores(a.actual,a.baseline)['RMSE']-m['RMSE']
        vals.append(m)
    return [{'metric':k,'lower_95':float(np.nanpercentile([v[k] for v in vals],2.5)),
             'upper_95':float(np.nanpercentile([v[k] for v in vals],97.5))}
            for k in ['MAE','RMSE','R2','RMSE_gain_vs_mean']]

master=pd.read_excel(INPUT/'source_master.xlsx',sheet_name='Master_104_Matches')
master['match_date']=pd.to_datetime(master.match_date)
master=master.sort_values(['match_date','match_id']).reset_index(drop=True)
assert len(master)==104 and master.match_id.is_unique
assert np.allclose(master.team_a_goals-master.team_b_goals,master.goal_difference)
td=pd.read_csv(INPUT/'task22_data.csv',parse_dates=['match_date'])
assert len(td)==208 and (td.groupby('match_id').size()==2).all()
assert not td.duplicated(['match_id','team']).any()
# Reconstruct the four new Task 2.2 predictors independently from prior matches.
for row in td.itertuples():
    prev=master[(master.match_date<row.match_date)&((master.team_a==row.team)|(master.team_b==row.team))]
    conceded=np.where(prev.team_a==row.team,prev.team_b_goals,prev.team_a_goals).sum()
    assert row.wc_matches_played_before==len(prev)
    assert row.wc_goals_conceded_before==conceded
    assert row.is_host_nation==int(row.team in ['Mexico','Canada','USA'])
    assert row.is_knockout==int(row.stage!='Group Stage')
    m=master.set_index('match_id').loc[row.match_id]
    assert row.goals_scored==m['team_a_goals' if row.side=='A' else 'team_b_goals']

all_metrics=[];all_cv=[];all_tuning=[];all_folds=[];all_ci=[];summary={}
for task,data,predfile,settingsfile,target,predcol,splitcol,keys in [
    ('2.1',master,'task21_predictions.csv','task21_settings.json','goal_difference','predicted_goal_difference','dataset_split',['match_id']),
    ('2.2',td,'task22_predictions.csv','task22_settings.json','goals_scored','predicted_goals','data_split',['match_id','team'])]:
    label=task.replace('.','');dest=OUT/('task_'+label);dest.mkdir(exist_ok=True)
    cfg=json.loads((INPUT/settingsfile).read_text());features=cfg['features']
    assert len(features)==8 and data[features+[target]].notna().all().all()
    assert np.isfinite(data[features+[target]].to_numpy(float)).all()
    saved=pd.read_csv(INPUT/predfile,parse_dates=['match_date'])
    assert not saved.duplicated(keys).any()
    paired=data.merge(saved[keys+[target,predcol,splitcol]],on=keys,suffixes=('','_saved'),validate='one_to_one')
    assert len(paired)==len(data) and np.allclose(paired[target],paired[target+'_saved'])
    paired=paired.sort_values(['match_date','match_id']+(['side'] if task=='2.2' else [])).reset_index(drop=True)
    train=paired[paired[splitcol]=='train'].reset_index(drop=True)
    test=paired[paired[splitcol]=='test'].reset_index(drop=True)
    assert len(train)+len(test)==len(data)
    assert train.match_date.max()<test.match_date.min()
    assert set(train.match_id).isdisjoint(test.match_id)
    assert set(test.match_id)==set(range(83,105))
    X,y=train[features],train[target]
    ols=LinearRegression().fit(X,y)
    discrepancy=float(np.max(np.abs(ols.predict(paired[features])-paired[predcol])))
    assert discrepancy<1e-8, f'Supplied predictions not reproducible: {discrepancy}'
    for split,frame in [('train',train),('test',test)]:
        for name,p in [('Supplied OLS',frame[predcol]),('Mean baseline',np.repeat(y.mean(),len(frame))),('Median baseline',np.repeat(y.median(),len(frame)))]:
            all_metrics.append({'task':task,'model':name,'split':split,**scores(frame[target],p)})

    # Fixed candidate grid, evaluated only within original training partition.
    # CV values are selection scores, not unbiased post-selection estimates.
    folds=date_folds(train)
    candidates=[('OLS',None),('Mean baseline',None),('Median baseline',None)]
    candidates += [('Ridge',a) for a in [0.01,0.1,1,10,100,1000]]
    candidates += [('Lasso',a) for a in [0.001,0.01,0.05,0.1,0.5,1]]
    cvrows=[]
    for name,alpha in candidates:
        truths=[];preds=[];fold_rmse=[]
        for fold,(ti,vi) in enumerate(folds,1):
            model=estimator(name,alpha).fit(X.iloc[ti],y.iloc[ti]);p=model.predict(X.iloc[vi])
            metric=scores(y.iloc[vi],p);fold_rmse.append(metric['RMSE'])
            truths.extend(y.iloc[vi].tolist());preds.extend(p.tolist())
            all_cv.append({'task':task,'model':name,'alpha':alpha,'fold':fold,**metric})
        cvrows.append({'task':task,'model':name,'alpha':alpha,
            **scores(truths,preds),'fold_RMSE_SD':float(np.std(fold_rmse,ddof=1))})
    all_tuning.extend(cvrows)
    best=min([r for r in cvrows if r['model'] in ['OLS','Ridge','Lasso']],key=lambda r:r['RMSE'])
    for name in ['Ridge','Lasso']:
        selected=min([r for r in cvrows if r['model']==name],key=lambda r:r['RMSE'])
        model=estimator(name,selected['alpha']).fit(X,y)
        pp=model.predict(test[features])
        all_metrics.append({'task':task,'model':name,'split':'test','alpha':selected['alpha'],**scores(test[target],pp)})
    for fold,(ti,vi) in enumerate(folds,1):
        all_folds.append({'task':task,'fold':fold,'train_rows':len(ti),'validation_rows':len(vi),
            'train_matches':train.iloc[ti].match_id.nunique(),'validation_matches':train.iloc[vi].match_id.nunique(),
            'train_last_date':str(train.iloc[ti].match_date.max().date()),
            'validation_first_date':str(train.iloc[vi].match_date.min().date()),
            'validation_last_date':str(train.iloc[vi].match_date.max().date()),
            'constant_training_features':'; '.join(c for c in features if train.iloc[ti][c].nunique()==1)})
    diag=test.copy();diag['actual']=diag[target];diag['predicted']=diag[predcol]
    diag['residual']=diag.actual-diag.predicted
    diag['absolute_error']=diag.residual.abs();diag['squared_error']=diag.residual**2
    diag['baseline']=y.mean()
    diag.to_csv(dest/'test_diagnostics.csv',index=False)
    diag.sort_values('absolute_error',ascending=False).head(8).to_csv(dest/'largest_errors.csv',index=False)
    stage=[{'stage':s,**scores(g.actual,g.predicted)} for s,g in diag.groupby('stage',sort=False)]
    pd.DataFrame(stage).to_csv(dest/'errors_by_stage.csv',index=False)
    cis=bootstrap_metrics(diag)
    all_ci.extend([{'task':task,**c} for c in cis])

    # Training leverage and Cook's distance: diagnostic flags, never automatic deletions.
    Z=StandardScaler().fit_transform(X);design=np.column_stack([np.ones(len(X)),Z])
    rank=np.linalg.matrix_rank(design);hat=np.sum(design*np.linalg.pinv(design).T,axis=1)
    residual=y.to_numpy()-ols.predict(X);mse=float(np.dot(residual,residual)/(len(X)-rank))
    cook=residual**2/(rank*mse)*hat/(1-hat)**2
    influence=train[keys+['match_date']].copy()
    influence['leverage']=hat;influence['cooks_distance']=cook
    influence['screen_flag']=cook>4/len(X)
    influence.to_csv(dest/'training_influence.csv',index=False)

    fig,axes=plt.subplots(2,2,figsize=(11,8))
    a=axes[0,0];a.scatter(diag.actual,diag.predicted,c='#245B86',alpha=.75,edgecolors='white')
    lo=min(diag.actual.min(),diag.predicted.min())-.3;hi=max(diag.actual.max(),diag.predicted.max())+.3
    a.plot([lo,hi],[lo,hi],'--',c='#AD5638',lw=1.4)
    a.set(xlabel='Actual outcome (goals)',ylabel='Predicted outcome (goals)',title='Actual versus predicted')
    a=axes[0,1];a.scatter(diag.predicted,diag.residual,c='#245B86',alpha=.8,edgecolors='white');a.axhline(0,c='#AD5638',ls='--')
    a.set(xlabel='Predicted outcome (goals)',ylabel='Residual: actual − predicted',title='Residual patterns')
    a=axes[1,0];a.hist(diag.residual,bins=8,color='#245B86',edgecolor='white');a.axvline(0,c='#AD5638',ls='--')
    a.set(xlabel='Residual (goals)',ylabel='Team rows' if task=='2.2' else 'Matches',title='Error distribution')
    a=axes[1,1];(theoretical,ordered),(slope,intercept,_) = stats.probplot(diag.residual,dist='norm')
    a.scatter(theoretical,ordered,c='#245B86',alpha=.8);a.plot(theoretical,intercept+slope*theoretical,c='#AD5638',ls='--')
    a.set(xlabel='Normal theoretical quantile',ylabel='Ordered residual (goals)',title='Q–Q plot: descriptive only')
    mm=scores(diag.actual,diag.predicted)
    fig.suptitle(f'Task {task}: supplied OLS, final test set\n{len(diag)} rows / 22 matches · MAE {mm["MAE"]:.3f} · RMSE {mm["RMSE"]:.3f} · R² {mm["R2"]:.3f}',fontsize=14,fontweight='bold')
    fig.tight_layout(rect=(0,0,1,.93));fig.savefig(dest/'diagnostics.png',dpi=180);plt.close(fig)
    summary[task]={'train_rows':len(train),'test_rows':len(test),'test_matches':22,
        'test_start':str(test.match_date.min().date()),'max_reproduction_difference':discrepancy,
        'training_design_rank':int(rank),'training_design_columns':9,
        'training_condition_number_standardized':float(np.linalg.cond(design)),
        'cook_flags':int((cook>4/len(X)).sum()),'negative_test_predictions':int((diag.predicted<0).sum()),
        'cv_selected_model':best['model'],'cv_selected_alpha':best['alpha'],
        'test_metrics_supplied_OLS':mm,'all_test_rows_knockout':bool((test.stage!='Group Stage').all()),
        'largest_error_match_ids':diag.sort_values('absolute_error',ascending=False).head(3).match_id.tolist()}

pd.DataFrame(all_metrics).to_csv(OUT/'model_metrics.csv',index=False)
pd.DataFrame(all_cv).to_csv(OUT/'cv_fold_metrics.csv',index=False)
pd.DataFrame(all_tuning).to_csv(OUT/'cv_candidate_summary.csv',index=False)
pd.DataFrame(all_folds).to_csv(OUT/'cv_date_windows.csv',index=False)
pd.DataFrame(all_ci).to_csv(OUT/'bootstrap_intervals.csv',index=False)
summary['environment']={'python_note':'Python 3','sklearn':sklearn.__version__,'numpy':np.__version__,'pandas':pd.__version__}
summary['input_sha256']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in INPUT.iterdir() if p.is_file()}
(OUT/'evaluation_summary.json').write_text(json.dumps(summary,indent=2))
fig,axes=plt.subplots(1,2,figsize=(10,4.6))
met=pd.DataFrame(all_metrics)
for ax,task in zip(axes,['2.1','2.2']):
    t=met[(met.task==task)&(met.split=='test')]
    ax.barh(t.model,t.RMSE,color=['#245B86','#A8ADB5','#C6CAD0','#4E8D74','#B07B52'])
    for i,v in enumerate(t.RMSE):ax.text(v+.025,i,f'{v:.3f}',va='center',fontsize=9)
    ax.set_xlim(0,t.RMSE.max()*1.23);ax.invert_yaxis();ax.set(title=f'Task {task}',xlabel='Final test RMSE (goals; lower is better)')
fig.suptitle('Supplied OLS and supplementary comparisons\nRidge/Lasso penalties selected using training dates only',fontsize=13,fontweight='bold')
fig.tight_layout(rect=(0,0,1,.88));fig.savefig(OUT/'model_comparison.png',dpi=180);plt.close(fig)
print(json.dumps({k:v for k,v in summary.items() if k in ['2.1','2.2']},indent=2))
print(met.to_string(index=False))
